# ================================
# STEP A: Import required libraries
# ================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

print("Step A complete: Libraries imported")


# ================================
# STEP B: Load the dataset
# ================================

df = pd.read_csv("data/instagram_influencers.csv")

print("\nStep B complete: Dataset loaded")
print("Shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())


# ================================
# STEP C: Basic dataset inspection
# ================================

print("\nStep C: Dataset Info")
print(df.info())

print("\nColumn names:")
print(df.columns)

print("\nMissing values per column:")
print(df.isna().sum())

# ================================
# STEP D1: Inspect sample values
# ================================

print("\nStep D1: Sample values from key columns")

sample_cols = df.columns[:10]  # show first few columns
for col in sample_cols:
    print(f"\nColumn: {col}")
    print(df[col].astype(str).head(5))

# ================================
# STEP D2: Function to clean M / K / % values
# ================================

def clean_numeric(value):
    if pd.isna(value):
        return np.nan
    
    value = str(value).strip().lower()
    
    try:
        if value.endswith('m'):
            return float(value.replace('m', '')) * 1_000_000
        elif value.endswith('k'):
            return float(value.replace('k', '')) * 1_000
        elif value.endswith('%'):
            return float(value.replace('%', '')) / 100
        else:
            return float(value.replace(',', ''))
    except:
        return np.nan

# ================================
# STEP D3: Apply cleaning function
# ================================

numeric_like_cols = [
    col for col in df.columns
    if any(key in col.lower() for key in ["followers", "likes", "rate", "score"])
]

print("\nNumeric-like columns detected:")
print(numeric_like_cols)

for col in numeric_like_cols:
    df[col] = df[col].apply(clean_numeric)

print("\nStep D3 complete: Numeric columns cleaned")
print(df[numeric_like_cols].head())

# ================================
# STEP D4: Handle missing values
# ================================

print("\nMissing values after cleaning:")
print(df[numeric_like_cols].isna().sum())

df[numeric_like_cols] = df[numeric_like_cols].fillna(
    df[numeric_like_cols].median()
)

print("Step D4 complete: Missing values filled with median")

# ================================
# STEP D5: Final dataset info
# ================================

print("\nStep D5: Final cleaned dataset info")
print(df.info())
print(df.head())

# ================================
# STEP E1: Basic statistics
# ================================

print("\nStep E1: Descriptive statistics")
print(df.describe())

# ================================
# STEP E1: Basic statistics
# ================================

print("\nStep E1: Descriptive statistics")
print(df.describe())

# ================================
# STEP E3: Followers vs Engagement Rate
# ================================

plt.figure(figsize=(7, 5))
plt.scatter(
    df["followers"],
    df["60_day_eng_rate"],
    alpha=0.5
)
plt.xlabel("Followers")
plt.ylabel("60-Day Engagement Rate")
plt.title("Followers vs Engagement Rate")
plt.tight_layout()
plt.savefig("followers_vs_engagement.png")
plt.close()

print("Step E3 complete: Followers vs Engagement plot saved")

# ================================
# STEP E4: Influence Score distribution
# ================================

plt.figure(figsize=(7, 5))
plt.hist(df["influence_score"], bins=30)
plt.xlabel("Influence Score")
plt.ylabel("Frequency")
plt.title("Distribution of Influence Score")
plt.tight_layout()
plt.savefig("influence_score_distribution.png")
plt.close()

print("Step E4 complete: Influence score distribution saved")

# ================================
# STEP E5: Correlation heatmap
# ================================

corr_cols = [
    "followers",
    "avg_likes",
    "60_day_eng_rate",
    "influence_score"
]

corr = df[corr_cols].corr()

plt.figure(figsize=(6, 5))
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Between Key Metrics")
plt.tight_layout()
plt.savefig("correlation_heatmap.png")
plt.close()

print("Step E5 complete: Correlation heatmap saved")

# ================================
# STEP F1: Regression - Feature Selection
# ================================

features_reg = [
    "followers",
    "avg_likes",
    "60_day_eng_rate"
]

X_reg = df[features_reg]
y_reg = df["influence_score"]

print("\nStep F1 complete: Regression features selected")
print(X_reg.head())

# ================================
# STEP F2: Linear Regression Model
# ================================

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import math

X_train, X_test, y_train, y_test = train_test_split(
    X_reg, y_reg, test_size=0.2, random_state=42
)

lr = LinearRegression()
lr.fit(X_train, y_train)

y_pred = lr.predict(X_test)

mae = mean_absolute_error(y_test, y_pred)
rmse = math.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

print("\n===== Linear Regression Results =====")
print("MAE:", round(mae, 3))
print("RMSE:", round(rmse, 3))
print("R² Score:", round(r2, 4))

# ================================
# STEP F3: Actual vs Predicted Plot
# ================================

plt.figure(figsize=(6, 6))
plt.scatter(y_test, y_pred, alpha=0.4)
plt.xlabel("Actual Influence Score")
plt.ylabel("Predicted Influence Score")
plt.title("Actual vs Predicted Influence Score")
plt.tight_layout()
plt.savefig("influence_actual_vs_pred.png")
plt.close()

print("Step F3 complete: Regression plot saved")

# ================================
# STEP F4: Create Influence Category
# ================================

df["Influence_Category"] = pd.qcut(
    df["influence_score"],
    q=3,
    labels=["Low", "Medium", "High"]
)

print("\nInfluence category distribution:")
print(df["Influence_Category"].value_counts())

# ================================
# STEP F5: Classification Model
# ================================

from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

features_cls = [
    "followers",
    "avg_likes",
    "60_day_eng_rate"
]

X_cls = df[features_cls]
y_cls = df["Influence_Category"]

# Encode target
le = LabelEncoder()
y_cls_enc = le.fit_transform(y_cls)

X_train_c, X_test_c, y_train_c, y_test_c = train_test_split(
    X_cls, y_cls_enc, test_size=0.2, random_state=42
)

rf = RandomForestClassifier(
    n_estimators=200,
    random_state=42,
    n_jobs=-1
)

rf.fit(X_train_c, y_train_c)
y_pred_c = rf.predict(X_test_c)

print("\n===== Random Forest Classification Results =====")
print("Accuracy:", round(accuracy_score(y_test_c, y_pred_c), 4))
print("\nClassification Report:\n", classification_report(y_test_c, y_pred_c))
